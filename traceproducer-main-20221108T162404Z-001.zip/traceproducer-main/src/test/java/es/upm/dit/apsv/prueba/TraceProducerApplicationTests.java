package es.upm.dit.apsv.prueba;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TraceProducerApplicationTests {

	@Test
	void contextLoads() {
	}

}
